// Express initialization
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var validator = require('validator');
var http = require('http');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/whereintheworld'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

app.post('/sendLocation', function (request, response) {
  
    //enable cross-origin resource sharing for API
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");

    var login = request.body.login; 
    var lat = request.body.lat;
    var lng = request.body.lng;
    var created_at = new Date();

    var toInsert = {
	"login": login,
	"lat": lat,
	"lng": lng,
	"created_at" : created_at
    };

    if (login != undefined && lat != undefined && lng != undefined &&
	validator.isFloat(lat) && validator.isFloat(lng)) {
	     if (lng <= 180 && lng >= -180 && lat <= 90 & lat >= -90) {
		 
		 db.collection('locations', function(er, collection) {
		     var id = collection.insert(toInsert, 
						function(err, saved) {
			if (err) {
			    response.send(500);
			} else if (!saved) {
			    response.send(500);
			} else { 
			    collection.find().sort({"created_at": -1}).limit(100).toArray(function(error, cursor) {
				if (!err) {
				    response.send(JSON.stringify({"characters": [], "students": cursor}));
				} else {
				    response.send(500);
				}
			   });  
			} 
		    }); 
		 }); 
	     } 
    }  
});

app.get('/locations.json', function (request, response) {

    //enable cors
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");

    response.setHeader('Content-Type', 'application/json'); //want type json
    var locationsPage = '';
    var login = request.query.login;

    if (login == undefined) {
	response.send(JSON.stringify([]));
    } else {
	db.collection('locations', function(er, collection) {
	    collection.find({"login": login}).sort({"created_at": -1}).toArray(function (err, cursor) {
		if (!err) {

		     if (cursor.length < 1) {
			 response.send(JSON.stringify([]));
		     } else {
			 response.send(JSON.stringify({"characters": [], "students": cursor}));
		     }
		} else { 
		    response.send(JSON.stringify([]));
		} 
	    });
	}); 
    } 
}); 

app.get('/', function (request, response) {

    response.set('Content-Type', 'text/html');
    var indexPage = '';
    db.collection('locations', function(er, collection) {
	collection.find().sort({"created_at": -1}).toArray(function
							   (err, cursor) {
	    if (!err) {
		console.log(cursor); 

		indexPage += "<!DOCTYPE html><html><head><title>Check-ins</title></head><body>";
		
		if (cursor.length < 1) { //empty array
		    response.send([]);
		    console.log("empty array");
		}

		for (var i = 0; i < cursor.length; i++) {
		    indexPage += "<p>" + cursor[i].login + " " + 
			cursor[i].created_at + " " + cursor[i].lat + " , " +
			cursor[i].lng + "</br></p>";
	        } 

		indexPage = indexPage + "</body></html>"
                response.send(indexPage);
	    } else {
		response.send("<!DOCTYPE HTML><html><head><title>Check-ins</title></head><body><h1>Something went wrong</h1></body></html>");
	    } 
	}); 
    }); 
});

app.get('/redline.json', function (request, response) {

    //enable CORS
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
    
    response.setHeader("Content-Type", "application/json");
    var options = {
	host: 'developer.mbta.com',
	port: 80,
	path: '/lib/rthr/red.json'
    };

    http.get(options, function(rawreq) {
	var data = '';
	rawreq.on('data', function(chunk) {
	data += chunk;
    });

    rawreq.on('end', function() {
        response.send(data);
    });

    }).on('error', function(e) {
//	console.log("Got error: " + e.message);
    });  
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);
