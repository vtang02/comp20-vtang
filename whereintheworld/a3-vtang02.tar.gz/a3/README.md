#Victoria Tang
##Assignment 3

1) All aspects of assignment 3 have been correctly implemented.
   /sendLocation-can add login/lat/lng to mongo database called locations
   /locations.json-returns json string of login's check-ins
   /-shows all check-ins
   /redline.json-returns json of redline trains

2) I got help from Ming, and Parker told me how to use curl.

3) I spent approximately 9 hours on this assignment. 